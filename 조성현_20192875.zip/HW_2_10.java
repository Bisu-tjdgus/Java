import java.util.Scanner;
public class HW_2_10 {
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);

        int x1,x2,y1,y2,r1,r2;
        System.out.print("첫번째 원의 중심과 반지름 입력>>");
        x1=scanner.nextInt();
        y1=scanner.nextInt();
        r1=scanner.nextInt();
        System.out.print("두번째 원의 중심과 반지름 입력>>");
        x2=scanner.nextInt();
        y2=scanner.nextInt();
        r2=scanner.nextInt();

        double distant=Math.sqrt(((x1-x2)*(x1-x2))+((y1-y2)*(y1-y2)));
        if(distant>(r1+r2)){
            System.out.print("두 원은 겹치지 않는다.");
        }
        else{
            System.out.print("두 원은 겹친다.");
        }
    }
}
