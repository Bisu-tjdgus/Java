import java.util.Scanner;
public class HW_2_12_1 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        double n1,n2,answer=0;
        String c;
        System.out.print("연산 >>");
        n1=scanner.nextInt();
        c=scanner.next();
        n2=scanner.nextInt();

        if(c.equals("+")){
            answer=n1+n2;
            System.out.print(n1+c+n2+"의 계산 결과는 " + answer);
        }
        else if(c.equals("-")){
            answer=n1-n2;
            System.out.print(n1+c+n2+"의 계산 결과는 " + answer);
        }
        else if(c.equals("*")){
            answer=n1*n2;
            System.out.print(n1+c+n2+"의 계산 결과는 " + answer);
        }
        else if(c.equals("/")){
            if(n2==0){
                System.out.print("0으로 나눌 수 없습니다!");
            }
            else {
                answer = n1 / n2;
                System.out.print(n1+c+n2+"의 계산 결과는 " + answer);
            }
        }
        else{
            System.out.print("입력하신 연산자가 부적절합니다!");
        }
    }
}