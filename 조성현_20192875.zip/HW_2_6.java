import  java.util.Scanner;
public class HW_2_6 {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.print("1~99 사이의 정수를 입력하시오>>");
        int num= scanner.nextInt();
        if((num/10)%3==0 && 10<num) //10의 자릿수가 3,6,9 일 때
        {
            if((num%10)%3==0){ //1의 자릿수가 3,6,9 일 때
                System.out.println("박수 짝짝!");
            }
            else{
                System.out.println("박수 짝!");
            }
        }
        else{
            if((num%10)%3==0){ //1의 자릿수가 3,6,9 일 때
                System.out.println("박수 짝!");
            }
            else{
                System.out.println("박수 없다!");
            }
        }
    }
}
