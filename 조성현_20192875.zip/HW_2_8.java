import  java.util.Scanner;
public class HW_2_8 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int x1,y1,x2,y2;
        System.out.print("x1, y1의 값을 입력해 주세요>>");
        x1 = scanner.nextInt();
        y1 = scanner.nextInt();
        System.out.print("x2, y2의 값을 입력해 주세요>>");
        x2 = scanner.nextInt();
        y2 = scanner.nextInt();
        int recx1,recx2,recy1,recy2;
        if(x1<=x2) {        //사각형 왼쪽 위 끝과 오른쪽 아래 끝을 사각형 점으로 잡음
            recx1=x1;       //각 점을 rec1, rec2로 한다.
            recx2=x2;
        }
        else{
            recx1=x2;
            recx2=x1;
        }
        if(y1<=y2){
            recy1=y1;
            recy2=y2;
        }
        else{
            recy1=y2;
            recy2=y1;
        }
        //사각형이 겹치는 부분이 있으면 충돌이라고 봄
        //
        //좌상단을 원점으로
        //(100, 100) (200 200)을 잡고 분할함
        //총 9개의 부분으로 쪼갬
        //
        //       100      200
        //        |        |
        //   1    |    2   |    3
        //        |        |
        //--------------------------- 100
        //        |        |
        //    4   |    5   |    6
        //        |        |
        //--------------------------- 200
        //        |        |
        //    7   |    8   |    9
        //        |        |

        if((recx1>=200) || (recy1>=200)){           //rec1이 1,2,4,5 번 밖에 있을 때
            System.out.println("사각형이 충돌하지 않습니다~~~");
        }
        else {
            if (recx1 <= 100 && recy1 <= 100) {           //rec1이 1번에 있을 때
                if (recx2 <= 100 || recy2 <= 100) {
                    System.out.println("사각형이 충돌하지 않습니다~~~");
                } else {
                    System.out.println("사각형이 충돌합니다!!!");
                }
            } else if (recx1 > 100 && recy1 <= 100) {        //rec1이 2번에 있을 때
                if (recy2 <= 100) {
                    System.out.println("사각형이 충돌하지 않습니다~~~");
                } else {
                    System.out.println("사각형이 충돌합니다!!!");
                }
            } else if (recx1 <= 100 && recy1 > 100) {       //rec1이 4번에 있을 때
                if (recx2 <= 100) {
                    System.out.println("사각형이 충돌하지 않습니다~~~");
                } else {
                    System.out.println("사각형이 충돌합니다!!!");
                }
            } else {                                        //rec1이 5번에 있을 때
                System.out.println("사각형이 충돌합니다!!!");
            }
        }
    }
}