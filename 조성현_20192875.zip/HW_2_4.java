import  java.util.Scanner;
public class HW_2_4 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("정수 3개 입력>>");
        int n1,n2,n3;
        n1=scanner.nextInt();
        n2=scanner.nextInt();
        n3=scanner.nextInt();
        if(n2<=n1 && n3<=n1) { //n1이 가장 클 때
            if (n2 <= n3) {
                System.out.println("중간 값은 " + n3);
            }
            else {
                System.out.println("중간 값은3 " + n2);
            }
        }
        else if(n1<=n2 && n3<=n2) { //n2가 가장 클 때
            if (n1 <= n3) {
                System.out.println("중간 값은 " + n3);
            }
            else {
                System.out.println("중간 값은 " + n1);
            }
        }
        else{
            if (n1 <= n2) { //n3이 가장 클 때
                System.out.println("중간 값은 " + n2);
            }
            else {
                System.out.println("중간 값은 " + n1);
            }
        }
    }
}
